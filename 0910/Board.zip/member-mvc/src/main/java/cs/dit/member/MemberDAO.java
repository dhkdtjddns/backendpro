package cs.dit.member;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;

import javax.naming.Context;
import javax.naming.InitialContext;
import javax.naming.NamingException;
import javax.sql.DataSource;

public class MemberDAO {
	
	//DB연동 커넥션 생성
	private Connection getConnection() throws Exception {
		
		//connection pool을 활용한 db연동
		Context initCtx = new InitialContext();
        Context envCtx = (Context) initCtx.lookup("java:comp/env");
        DataSource ds = (DataSource) envCtx.lookup("jdbc/sbkim");
        return ds.getConnection();
	}
	//데이터베이스에 데이터 저장
	public void insert(MemberDTO dto) {
		String sql = "INSERT INTO board(subject, content, writer, regdate) VALUES(?,?,?,SYSDATE())";
	        try (Connection con = getConnection();
	             PreparedStatement pstmt = con.prepareStatement(sql)) {
	            pstmt.setString(1, dto.getSubject());
	            pstmt.setString(2, dto.getContent());
	            pstmt.setString(3, dto.getWriter());
	            pstmt.executeUpdate();
	        } catch (Exception e) {
	            e.printStackTrace();
	        }
	}
	
	//글 목록
	public ArrayList<MemberDTO> list(int p, int numOfRecords){
		String sql = "SELECT bcode, subject, content, writer, regdate FROM board ORDER BY bcode DESC LIMIT ?,?";
        ArrayList<MemberDTO> dtos = new ArrayList<>();
        try (Connection con = getConnection();
             PreparedStatement pstmt = con.prepareStatement(sql)) {
            pstmt.setInt(1, (p - 1) * numOfRecords);
            pstmt.setInt(2, numOfRecords);
            ResultSet rs = pstmt.executeQuery();
            while (rs.next()) {
                MemberDTO dto = new MemberDTO(
                    rs.getInt("bcode"),
                    rs.getString("subject"),
                    rs.getString("content"),
                    rs.getString("writer"),
                    rs.getDate("regdate")
                );
                dtos.add(dto);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return dtos;
	}
	
	//전체 글 수 
	public int countRecords() {
		String sql = "SELECT COUNT(*) FROM board";
        int count = 0;
        try (Connection con = getConnection();
             Statement st = con.createStatement();
             ResultSet rs = st.executeQuery(sql)) {
            rs.next();
            count = rs.getInt(1);
        } catch (Exception e) {
            e.printStackTrace();
        }
        return count;
	}
	
	//updateForm에 출력할 데이터 가져오기
	public MemberDTO get(int bcode) {
		String sql = "SELECT * FROM board WHERE bcode=?";
        MemberDTO dto = null;
        try (Connection con = getConnection();
             PreparedStatement pstmt = con.prepareStatement(sql)) {
            pstmt.setInt(1, bcode);
            ResultSet rs = pstmt.executeQuery();
            if (rs.next()) {
                dto = new MemberDTO(
                    rs.getInt("bcode"),
                    rs.getString("subject"),
                    rs.getString("content"),
                    rs.getString("writer"),
                    rs.getDate("regdate")
                );
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return dto;
	}
	//update
	public void update(MemberDTO dto) {
		String sql = "UPDATE board SET subject=?, content=?, writer=? WHERE bcode=?";
        try (Connection con = getConnection();
             PreparedStatement pstmt = con.prepareStatement(sql)) {
            pstmt.setString(1, dto.getSubject());
            pstmt.setString(2, dto.getContent());
            pstmt.setString(3, dto.getWriter());
            pstmt.setInt(4, dto.getBcode());
            pstmt.executeUpdate();
        } catch (Exception e) {
            e.printStackTrace();
        }
	}
	public void delete(int bcode) {
		String sql = "DELETE FROM board WHERE bcode=?";
	    try (Connection con = getConnection();
	         PreparedStatement pstmt = con.prepareStatement(sql)) {
	        pstmt.setInt(1, bcode);
	        pstmt.executeUpdate();
	    } catch (Exception e) {
	        e.printStackTrace();
	    }
    }

}





