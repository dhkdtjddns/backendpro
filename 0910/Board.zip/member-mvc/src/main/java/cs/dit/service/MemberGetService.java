package cs.dit.service;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import cs.dit.member.MemberDAO;
import cs.dit.member.MemberDTO;

public class MemberGetService implements MemberService {

	@Override
	public void execute(HttpServletRequest request, HttpServletResponse response) {
		 // 글 번호(bcode) 파라미터 가져오기
        int bcode = Integer.parseInt(request.getParameter("bcode"));

        MemberDAO dao = new MemberDAO();
        MemberDTO dto = dao.get(bcode);

        // JSP에서 꺼내 쓸 수 있도록 저장
        request.setAttribute("dto", dto);
	}

}
