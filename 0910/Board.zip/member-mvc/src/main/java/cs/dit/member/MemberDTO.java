package cs.dit.member;

import java.sql.Date;

/**
 * 패키지명 : cs.dit.member
 * 파일명 : MemberDTO.java
 * 작성일 : 2025. 4. 16.
 * 작성자 : 김진숙
 * 변경이력 :
 * 프로그램 설명 : Member 테이블의 데이터를 담는 용기 
 *
 */
public class MemberDTO {
	
	private int bcode;        // 글 번호 (PK)
    private String subject;   // 제목
    private String content;   // 내용
    private String writer;    // 작성자
    private Date regdate;   // 작성일 (DATE → String 변환해서 가져와도 됨)
    
	
	public int getBcode() { return bcode; }
    public void setBcode(int bcode) { this.bcode = bcode; }

    public String getSubject() { return subject; }
    public void setSubject(String subject) { this.subject = subject; }

    public String getContent() { return content; }
    public void setContent(String content) { this.content = content; }

    public String getWriter() { return writer; }
    public void setWriter(String writer) { this.writer = writer; }

    public Date getRegdate() { return regdate; }
    public void setRegdate(Date regdate) { this.regdate = regdate; }

    public MemberDTO(int bcode, String subject, String content, String writer, Date regdate) {
        this.bcode = bcode;
        this.subject = subject;
        this.content = content;
        this.writer = writer;
        this.regdate = regdate;
    }

    public MemberDTO() {}

	
}
