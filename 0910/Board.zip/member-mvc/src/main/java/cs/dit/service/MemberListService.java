package cs.dit.service;

import java.util.ArrayList;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import cs.dit.member.MemberDAO;
import cs.dit.member.MemberDTO;

public class MemberListService implements MemberService {

	@Override
	public void execute(HttpServletRequest request, HttpServletResponse response) {
		
		MemberDAO dao = new MemberDAO();
        int count = dao.countRecords();
        int p = 1;
        int numOfRecords = 10;
        int numOfPages = 5;

        String p_ = request.getParameter("p");
        if (p_ != null && !p_.equals("")) p = Integer.parseInt(p_);

        int startNum = p - ((p - 1) % numOfPages);
        int lastNum = (int)Math.ceil(count / (float)numOfRecords);

        ArrayList<MemberDTO> dtos = dao.list(p, numOfRecords);

        request.setAttribute("p", p);
        request.setAttribute("startNum", startNum);
        request.setAttribute("lastNum", lastNum);
        request.setAttribute("numOfPages", numOfPages);
        request.setAttribute("dtos", dtos);
    }

}
