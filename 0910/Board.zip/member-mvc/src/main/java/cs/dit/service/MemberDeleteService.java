package cs.dit.service;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import cs.dit.member.MemberDAO;
import cs.dit.member.MemberDTO;

public class MemberDeleteService implements MemberService {

	@Override
	public void execute(HttpServletRequest request, HttpServletResponse response) {
		int bcode = Integer.parseInt(request.getParameter("bcode"));

		MemberDAO dao = new MemberDAO();
		MemberDTO dto = dao.get(bcode);
	}

}
