package cs.dit.service;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import cs.dit.member.MemberDAO;
import cs.dit.member.MemberDTO;

public class MemberInsertService implements MemberService {

	@Override
	public void execute(HttpServletRequest request, HttpServletResponse response){

		String subject = request.getParameter("subject");
        String content = request.getParameter("content");
        String writer  = request.getParameter("writer");

        MemberDTO dto = new MemberDTO();
        dto.setSubject(subject);
        dto.setContent(content);
        dto.setWriter(writer);

        MemberDAO dao = new MemberDAO();
        dao.insert(dto);

	}
}
